# Reproduce judge-6b4896fe6ae4d2b0e7988bd313f8530b

artifact_hash (sha256 over model.zip + vecnormalize.pkl digests): 896606505cb3d0017207be1d968de8d6defe86245509a9b3d11f307e2057656f

On Linux, after creating `.venv` and before installing `requirements.lock`, install the CPU wheel: `.venv/bin/pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu`.

```
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.lock
PYTHONPATH=source .venv/bin/python -m ew.cli evaluate --policy-dir policy --suite val-target-v1
```
Training: recipe ppo-r1 seed 29 steps 61440 on family static_crossing from parent physics-20261016150004-25da9c. Runtime: {"dynamics": "ew-dyn-1", "gymnasium": "1.4.0", "machine": "x86_64", "numpy": "2.5.4", "python": "3.13.5", "reward": "ew-reward-1", "stable_baselines3": "2.9.0", "torch": "2.14.1+cpu"}.
Bitwise identical retraining is not promised across hardware or package versions; evaluation of the
saved artifact on the same suite seeds is deterministic on the same package set.
