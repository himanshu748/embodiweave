# Reproduce physics development

Install requirements.lock then requirements-mujoco.txt. Extract this bundle and run:

```sh
PYTHONPATH=source .venv/bin/python reproduce_physics.py
```

This replays the published development seeds only. No confirmation rerun is included. Training used both 2D and MuJoCo, with training source captured separately in training-source.zip. No real-world safety claim.
