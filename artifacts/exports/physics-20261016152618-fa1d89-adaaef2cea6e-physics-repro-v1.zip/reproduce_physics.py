import os,json,shutil
from pathlib import Path
p=json.load(open('physics-development/protocol.json'))
pid=p['policies']['candidate']['id']
os.environ['EW_ARTIFACTS']=str(Path('reproduction-artifacts').resolve())
d=Path(os.environ['EW_ARTIFACTS'])/'policies'/pid
d.mkdir(parents=True,exist_ok=True)
for n in ('model.zip','vecnormalize.pkl','manifest.json'):shutil.copyfile(Path('policy')/n,d/n)
from sim.mujoco.evaluate import run
run(p,Path('reproduced-development'))
