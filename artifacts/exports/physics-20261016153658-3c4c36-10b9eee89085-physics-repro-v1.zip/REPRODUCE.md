# Reproduce physics-20261016153658-3c4c36

artifact_hash (sha256 over model.zip + vecnormalize.pkl digests): 10b9eee89085605b7adf4c2dbb5a04a266f862a0ebeb52b1c17327f035058f1d

On Linux, after creating `.venv` and before installing `requirements.lock`, install the CPU wheel: `.venv/bin/pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu`.

```
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.lock
PYTHONPATH=source .venv/bin/python -m ew.cli evaluate --policy-dir policy --suite val-target-v1
```
Training: recipe ppo-mixed-mujoco-lr-v1 seed 23 steps 600064 on family static_crossing from parent physics-20261016152618-fa1d89. Runtime: {"dynamics": "ew-dyn-1", "gymnasium": "1.4.0", "machine": "arm64", "numpy": "2.5.4", "python": "3.13.15", "reward": "ew-reward-1", "stable_baselines3": "2.9.0", "torch": "2.14.1"}.
Bitwise identical retraining is not promised across hardware or package versions; evaluation of the
saved artifact on the same suite seeds is deterministic on the same package set.
