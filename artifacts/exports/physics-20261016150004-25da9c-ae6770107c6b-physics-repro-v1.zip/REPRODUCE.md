# Reproduce physics-20261016150004-25da9c

artifact_hash (sha256 over model.zip + vecnormalize.pkl digests): ae6770107c6b7c4d6358f91cef8f084c440c753ab4dd6775615dfa25c2182150

On Linux, after creating `.venv` and before installing `requirements.lock`, install the CPU wheel: `.venv/bin/pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu`.

```
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.lock
PYTHONPATH=source .venv/bin/python -m ew.cli evaluate --policy-dir policy --suite val-target-v1
```
Training: recipe ppo-mixed-mujoco-collision40-v1 seed 23 steps 301056 on family static_crossing from parent robust-20261016140226-352fd7. Runtime: {"dynamics": "ew-dyn-1", "gymnasium": "1.4.0", "machine": "arm64", "numpy": "2.5.4", "python": "3.13.15", "reward": "ew-reward-1", "stable_baselines3": "2.9.0", "torch": "2.14.1"}.
Bitwise identical retraining is not promised across hardware or package versions; evaluation of the
saved artifact on the same suite seeds is deterministic on the same package set.
