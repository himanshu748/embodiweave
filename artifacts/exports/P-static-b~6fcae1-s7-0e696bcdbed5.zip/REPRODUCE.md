# Reproduce P-static-b~6fcae1-s7

artifact_hash (sha256 over model.zip + vecnormalize.pkl digests): 0e696bcdbed5769e0494e30682f17e194f86263406c0085c1f4a7a54959b568a

```
pip install -r requirements.lock
python -m ew.cli evaluate --policy-dir policy --suite val-target-v1
```
Training: recipe ppo-r1 seed 7 steps 151552 on family static_crossing from parent P-static-b. Runtime: {"dynamics": "ew-dyn-1", "gymnasium": "1.4.0", "machine": "x86_64", "numpy": "2.5.4", "python": "3.13.16", "reward": "ew-reward-1", "stable_baselines3": "2.9.0", "torch": "2.14.1+cu130"}.
Bitwise identical retraining is not promised across hardware or package versions; evaluation of the
saved artifact on the same suite seeds is deterministic on the same package set.
