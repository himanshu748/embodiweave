# Reproduce scratch~a7ee2c-s7

artifact_hash (sha256 over model.zip + vecnormalize.pkl digests): 556ec083bc8589363d034745bac670bf7e0afb17fedf138ea0fd8b8797066baa

```
pip install -r requirements.lock
python -m ew.cli evaluate --policy-dir policy --suite val-target-v1
```
Training: recipe ppo-r1 seed 7 steps 151552 on family static_crossing from parent scratch. Runtime: {"dynamics": "ew-dyn-1", "gymnasium": "1.4.0", "machine": "x86_64", "numpy": "2.5.4", "python": "3.13.16", "reward": "ew-reward-1", "stable_baselines3": "2.9.0", "torch": "2.14.1+cu130"}.
Bitwise identical retraining is not promised across hardware or package versions; evaluation of the
saved artifact on the same suite seeds is deterministic on the same package set.
