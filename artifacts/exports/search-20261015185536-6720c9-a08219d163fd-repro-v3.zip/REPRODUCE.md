# Reproduce search-20261015185536-6720c9

artifact_hash (sha256 over model.zip + vecnormalize.pkl digests): a08219d163fdb404bf481f544ceb158c63e33e49baf75685e5e7aae07b87941b

On Linux, after creating `.venv` and before installing `requirements.lock`, install the CPU wheel: `.venv/bin/pip install torch==2.14.1+cpu --index-url https://download.pytorch.org/whl/cpu`.

```
python3.13 -m venv .venv
.venv/bin/pip install -r requirements.lock
PYTHONPATH=source .venv/bin/python -m ew.cli evaluate --policy-dir policy --suite val-target-v1
```
Training: recipe ppo-r1 seed 7 steps 301056 on family static_crossing from parent scratch~10715f-s7. Runtime: {"dynamics": "ew-dyn-1", "gymnasium": "1.4.0", "machine": "arm64", "numpy": "2.5.4", "python": "3.13.15", "reward": "ew-reward-1", "stable_baselines3": "2.9.0", "torch": "2.14.1"}.
Bitwise identical retraining is not promised across hardware or package versions; evaluation of the
saved artifact on the same suite seeds is deterministic on the same package set.
